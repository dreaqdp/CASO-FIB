#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>
#include <string.h>

int main(int argc, char * argv[]) {

   int res;

   if (argc < 3) {
	printf("USAGE: ./mtask -r/-s pids \n");
	exit(1);
   }

//   if (argv[1] == "-r") {
	for (int i = 2; i < argc; i++) {
		int pid;
		pid = atoi (argv[i]);
		task_t t = pid2task((pid_t)pid);

		if (!strcmp(argv[1], "-r")) { 
			res = task_resume((mach_port_t) t); 
			printf("task resumed\n");
		}
		else{ 
			res = task_suspend((mach_port_t) t);
			printf("task suspended\n");
		}
   		if (res != KERN_SUCCESS) {
		      	printf ("Error changing task state (0x%x), %s\n", res, 
		      	mach_error_string(res));
		      	exit(1);
		}
	}
  // }
  

}
