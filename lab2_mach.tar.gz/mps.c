#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>


int main() {

   int res, i;
   mach_port_t host_privileged_port;
   device_t device_privileged_port;

   res = get_privileged_ports(&host_privileged_port, &device_privileged_port);
   if (res != KERN_SUCCESS) {
      	printf ("Error getting privileged ports (0x%x), %s\n", res, 
      	mach_error_string(res));
      	exit(1);
   }
   
   
   mach_port_t defproc;
   res = processor_set_default(host_privileged_port, &defproc);
   if (res != KERN_SUCCESS) {
      	printf ("Error getting default processor (0x%x), %s\n", res, 
      	mach_error_string(res));
      	exit(1);
   }
   
   mach_port_t proc_set;
   res = host_processor_set_priv(host_privileged_port, defproc, &proc_set);
   if (res != KERN_SUCCESS) {
      	printf ("Error getting default processor (0x%x), %s\n", res, 
      	mach_error_string(res));
      	exit(1);
   }
  
   task_array_t tasks;
   mach_msg_type_number_t task_count;
   res = processor_set_tasks(proc_set, &tasks, &task_count); 
   if (res != KERN_SUCCESS) {
      	printf ("Error getting default processor tasks (0x%x), %s %d\n", res, 
        mach_error_string(res),defproc);
      	exit(1);
   }
   
/*
   res = host_processor_set_priv();
   */
   for (int i = 0; i < task_count; i++) { 
	/*task_info_t task_info;
   	res = task_info(tasks[i], TASK_BASIC_INFO, task_info, TASK_BASIC_INFO_COUNT);

   	if (res != KERN_SUCCESS) {
      		printf ("Error getting default processor tasks (0x%x), %s\n", res, 
                mach_error_string(res));
      		exit(1);
   	}*/

	Print_Task_info(tasks[i]);
	printf("\n");


   }
   //int * p;
}
