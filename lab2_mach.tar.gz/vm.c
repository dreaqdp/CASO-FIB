#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <mach/i386/vm_param.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>
#include <string.h>


int main(int argc, char * argv[]) {

	int res;
	mach_port_t child_task;
	res = task_create (mach_task_self(), 0, &child_task);
	
	if (res != KERN_SUCCESS) {
      		printf ("Error creating task (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}

	int size = I386_PGBYTES * 4;

	printf("child task pid : %d\n",task2pid(child_task));	
	vm_address_t  addr = 0x10000000;
	res = vm_allocate (child_task, &addr, size, 1);
	if (res != KERN_SUCCESS) {
      		printf ("Error allocating virtual mem (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}
	printf("done vm_allocate, addr: %d\n", addr);
	char mem[size] __attribute__((aligned (4096)));
	for(int i=0; i<size;++i) mem[i] = i%256;
	//for(int i=0; i<size/sizeof(int);++i) mem[i] = i%256;
	res = vm_write (child_task, addr, (vm_offset_t)mem, (mach_msg_type_number_t)size);
	if (res != KERN_SUCCESS) {
      		printf ("Error writing virtual mem (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}

	while(1);
/*
	struct i386_thread_state state;
	mach_msg_type_number_t stateCount = THREAD_STATE_MAX;
	res = thread_get_state (child_thread, i386_THREAD_STATE, (thread_state_t)&state, &stateCount);
		
	if (res != KERN_SUCCESS) {
      		printf ("Error getting thread state (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}
	char buff[666];
	state.eip = &useless;
	state.uesp = &buff[666-4];
	res = thread_set_state(child_thread, i386_THREAD_STATE, (thread_state_t)&state, stateCount);
	if (res != KERN_SUCCESS) {
      		printf ("Error setting thread state (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}
	
	res = thread_resume(child_thread);
	if (res != KERN_SUCCESS) {
      		printf ("Error resuming thread (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}

	//sleep(20);
	while(1);	

*/
}
