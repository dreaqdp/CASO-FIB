#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <mach/i386/vm_param.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>
#include <string.h>


int main(int argc, char * argv[]) {

	int res;
	mach_port_t target_task = pid2task(atoi(argv[1]));


//	int size = I386_PGBYTES;

	vm_address_t addr = atoi(argv[2]);
	vm_offset_t *data;
	mach_msg_type_number_t data_count;
	res = vm_read (target_task, addr, sizeof(int), &data, &data_count);

	if (res != KERN_SUCCESS) {
      		printf ("Error reading virtual mem (0x%x), %s \n", res, 
	        mach_error_string(res));
      		exit(1);
	}
	printf("done\n");
//	char tmp [(int)data_count] = &data;
	for (int i=0; i<data_count; ++i){
		printf("byte %d : %x\n",i,((char*)data)[i]);
	}
	//printf("data: %04x, data_count: %d\n", *data, (int)data_count);
}
